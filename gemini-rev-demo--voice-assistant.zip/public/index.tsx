import React, { useState, useRef, useEffect, useCallback } from 'react';
import ReactDOM from 'react-dom/client';
import { Mic, Cpu } from 'react-feather';
import { floatTo16BitPCM } from './audio.js';

type TranscriptItem = {
  source: 'user' | 'ai';
  text: string;
};

type Status = 'idle' | 'connecting' | 'listening' | 'speaking' | 'error';

const b64encode = (buffer: ArrayBuffer) => {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
};

const App = () => {
  const [status, setStatus] = useState<Status>('idle');
  const [transcript, setTranscript] = useState<TranscriptItem[]>([]);
  const [interimTranscript, setInterimTranscript] = useState('');
  const [isSessionActive, setIsSessionActive] = useState(false);

  const ws = useRef<WebSocket | null>(null);
  const audioContext = useRef<AudioContext | null>(null);
  const audioWorkletNode = useRef<AudioWorkletNode | null>(null);
  const micStream = useRef<MediaStream | null>(null);
  const audioQueue = useRef<ArrayBuffer[]>([]);
  const isPlayingAudio = useRef(false);
  const aiResponseRef = useRef('');
  const transcriptEndRef = useRef<HTMLDivElement>(null);

  const playNextAudioChunk = useCallback(() => {
    if (isPlayingAudio.current || audioQueue.current.length === 0) {
      if (!isPlayingAudio.current && isSessionActive) {
         setStatus('listening');
      }
      return;
    }
    isPlayingAudio.current = true;
    setStatus('speaking');

    const pcmData = audioQueue.current.shift();
    if (!pcmData || !audioContext.current) {
      isPlayingAudio.current = false;
      return;
    }
    
    const float32Array = new Float32Array(pcmData.byteLength / 2);
    const dataView = new DataView(pcmData);
    for (let i = 0; i < float32Array.length; i++) {
        float32Array[i] = dataView.getInt16(i * 2, true) / 32768.0;
    }

    const audioBuffer = audioContext.current.createBuffer(1, float32Array.length, 16000);
    audioBuffer.copyToChannel(float32Array, 0);

    const source = audioContext.current.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(audioContext.current.destination);
    source.onended = () => {
      isPlayingAudio.current = false;
      playNextAudioChunk();
    };
    source.start();
  }, [isSessionActive]);

  const startSession = async () => {
    if (isSessionActive) return;
    
    setIsSessionActive(true);
    setStatus('connecting');
    setTranscript([]);
    setInterimTranscript('');
    aiResponseRef.current = '';

    try {
      const proto = window.location.protocol.startsWith('https') ? 'wss' : 'ws';
      const socket = new WebSocket(`${proto}://${window.location.host}/ws`);
      ws.current = socket;

      socket.onopen = async () => {
        setStatus('listening');
        audioContext.current = new AudioContext({ sampleRate: 16000 });
        
        await audioContext.current.audioWorklet.addModule('audio-processor.js');
        audioWorkletNode.current = new AudioWorkletNode(audioContext.current, 'audio-processor', {
            processorOptions: { sampleRate: audioContext.current.sampleRate }
        });

        audioWorkletNode.current.port.onmessage = (event) => {
          const pcm = floatTo16BitPCM(event.data);
          const base64 = b64encode(pcm.buffer);
          if (socket.readyState === WebSocket.OPEN) {
            socket.send(JSON.stringify({ audio: base64 }));
          }
        };
        
        micStream.current = await navigator.mediaDevices.getUserMedia({ audio: true });
        const source = audioContext.current.createMediaStreamSource(micStream.current);
        source.connect(audioWorkletNode.current);
        // We don't connect to destination, to avoid hearing ourselves.
      };

      socket.onmessage = (event) => {
        if (typeof event.data !== 'string') return;
        const message = JSON.parse(event.data);

        if (message.error) {
            console.error('Error from server:', message.error.message || message.error);
            setStatus('error');
            return;
        }

        if (message.result?.is_final) {
             setTranscript(prev => [...prev, { source: 'user', text: message.result.transcript }]);
        }

        if (message.response?.text) {
            aiResponseRef.current += message.response.text;
            setInterimTranscript(aiResponseRef.current);
        }

        if (message.response?.audio) {
            const audioData = atob(message.response.audio);
            const audioBytes = new Uint8Array(audioData.length);
            for (let i = 0; i < audioData.length; i++) {
                audioBytes[i] = audioData.charCodeAt(i);
            }
            audioQueue.current.push(audioBytes.buffer);
            playNextAudioChunk();
        }

        if (message.response_finished) {
            if (aiResponseRef.current) {
                setTranscript(prev => [...prev, { source: 'ai', text: aiResponseRef.current }]);
                aiResponseRef.current = '';
                setInterimTranscript('');
            }
        }
      };

      socket.onclose = () => {
        stopSession(false);
      };

      socket.onerror = (error) => {
        console.error('WebSocket error:', error);
        setStatus('error');
        stopSession(false);
      };

    } catch (err) {
      console.error('Failed to start session:', err);
      setStatus('error');
      setIsSessionActive(false);
    }
  };

  const stopSession = (shouldCloseSocket = true) => {
    if (!isSessionActive && status !== 'error') return;

    if (shouldCloseSocket && ws.current) {
      ws.current.close();
    }
    ws.current = null;

    micStream.current?.getTracks().forEach(track => track.stop());
    micStream.current = null;
    
    audioWorkletNode.current?.disconnect();
    audioWorkletNode.current = null;

    audioContext.current?.close().then(() => {
      audioContext.current = null;
    });

    audioQueue.current = [];
    isPlayingAudio.current = false;
    
    setStatus('idle');
    setIsSessionActive(false);
  };

  useEffect(() => {
    transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [transcript, interimTranscript]);

  const getStatusText = () => {
    switch (status) {
      case 'connecting': return 'Connecting...';
      case 'listening': return 'Listening...';
      case 'speaking': return 'AI is speaking...';
      case 'error': return 'An error occurred.';
      default: return 'Click the mic to start';
    }
  };

  const orbClass = `orb ${isSessionActive ? status : ''}`;

  return (
    <div className="app-container">
      <header>
        <h1>Gemini Voice</h1>
        <div className="status-indicator">{getStatusText()}</div>
      </header>
      <main className="transcript-container">
        {transcript.map((item, index) => (
          <div key={index} className={`transcript-item ${item.source}`}>
            {item.source === 'user' ? <Mic size={18} style={{flexShrink: 0}} /> : <Cpu size={18} style={{flexShrink: 0}} />}
            <p>{item.text}</p>
          </div>
        ))}
        {interimTranscript && (
          <div className="transcript-item ai">
             <Cpu size={18} style={{flexShrink: 0}} />
             <p>{interimTranscript}</p>
          </div>
        )}
        <div ref={transcriptEndRef} />
      </main>
      <footer className="controls-container">
         <div className="orb-container">
            <button className={orbClass} onClick={isSessionActive ? () => stopSession() : startSession} aria-label={isSessionActive ? 'Stop session' : 'Start session'}>
              { (status === 'listening' || status === 'speaking') && <div className="orb-wave" /> }
              <Mic size={28} color="white"/>
            </button>
         </div>
         <p>
           {isSessionActive ? "Click the mic to end session" : "Click the mic to start"}
         </p>
      </footer>
    </div>
  );
};

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<React.StrictMode><App /></React.StrictMode>);