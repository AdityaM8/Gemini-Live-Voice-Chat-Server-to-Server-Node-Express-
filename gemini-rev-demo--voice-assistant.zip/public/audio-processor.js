class AudioProcessor extends AudioWorkletProcessor {
  constructor(options) {
    super();
    this.sourceSampleRate = options.processorOptions.sampleRate;
    this.targetSampleRate = 16000;
    this.resampleRatio = this.sourceSampleRate / this.targetSampleRate;
    
    // Buffer for 100ms of audio to be sent
    this.bufferSize = 1600; // 100ms at 16kHz
    this.internalBuffer = new Float32Array(this.bufferSize);
    this.internalBufferIndex = 0;

    this.lastSample = 0;
  }

  process(inputs) {
    const input = inputs[0];
    if (input && input.length > 0) {
      const channelData = input[0];
      let i = this.lastSample;
      while (i < channelData.length) {
        if (this.internalBufferIndex < this.bufferSize) {
          this.internalBuffer[this.internalBufferIndex++] = channelData[Math.floor(i)];
        }
        
        if (this.internalBufferIndex === this.bufferSize) {
          this.port.postMessage(this.internalBuffer);
          this.internalBufferIndex = 0;
        }
        i += this.resampleRatio;
      }
      this.lastSample = i - channelData.length;
    }
    return true;
  }
}

try {
    registerProcessor('audio-processor', AudioProcessor);
} catch(e) {
    console.error(e)
}
