import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer } from 'ws';
import { GeminiLiveSession } from './geminiProxy.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.API_KEY;
const MODEL = process.env.GEMINI_LIVE_MODEL || 'gemini-2.5-flash-preview-native-audio-dialog';

app.use(express.static(path.join(__dirname, '../public')));

wss.on('connection', async (client) => {
  console.log('Client connected');
  // One Gemini session per browser client
  const session = new GeminiLiveSession({
    apiKey: API_KEY,
    model: MODEL,
    systemPromptPath: path.join(__dirname, 'systemPrompt.txt')
  });

  await session.connect();

  // Pipe Gemini → Browser
  session.on('message', (data) => {
    // Pass through as-is (audio chunks, partial transcripts, etc.)
    client.send(data);
  });

  session.on('close', (code, reason) => {
    console.log(`Gemini session closed: ${code} ${reason}`);
    client.close();
  });
  session.on('error', (err) => {
    console.error('Gemini session error:', err);
    client.send(JSON.stringify({ error: String(err) }));
  });

  // Pipe Browser → Gemini
  client.on('message', (data) => {
    // Client sends JSON with base64 audio or text
    session.send(data.toString());
  });

  client.on('close', (code, reason) => {
    console.log(`Client disconnected: ${code} ${reason}`);
    session.close();
  });
});

server.listen(PORT, () => console.log(`\n▶ Voice app running: http://localhost:${PORT}\n`));