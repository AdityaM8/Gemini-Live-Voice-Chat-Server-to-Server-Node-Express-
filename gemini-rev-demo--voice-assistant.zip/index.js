// This file is intentionally left blank.
// It was a deprecated server entry point that caused errors when loaded in the browser.
// The correct server entry point is `server/index.js`.
